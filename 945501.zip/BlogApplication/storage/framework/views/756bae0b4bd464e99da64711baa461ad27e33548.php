<?php $__env->startSection('title','Posts'); ?>

<?php $__env->startSection('content'); ?>
<br>
<div class="row">
   <div class="col-md-10">
        <h1>The blog posts of E world:</h1>
   </div>
   
   <div class="col-md-2">
        <a href="<?php echo e(route('posts.create')); ?>" class=" btn btn-block btn-primary btn-sm">Create New Post</a>
   </div>
   <hr>
</div>
<div class="row">
    <div class="col-md-12">
        <table class="table table-striped">
            <thead class="thead-dark">
                <th>#</th>
                <th>Title</th>
                <th>Body</th>
                <th>Created At</th>
                <th></th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($post->id); ?></th>
                        <td> <?php echo e($post->title); ?></td>
                        <td><?php echo e(substr($post->content,0,50)); ?><?php echo e(strlen($post->body) > 50 ? "..." : " "); ?></td>
                        <td> <?php echo e(date('M j,Y',strtotime($post->created_at))); ?></td>
                        <td><a href="<?php echo e(route('posts.show',$post->id)); ?>" class="btn btn-default btn-sm btn-outline-primary" >View</a>
                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>
                            <a href="<?php echo e(route('posts.edit',$post->id)); ?>" class="btn btn-default btn-sm btn-outline-primary ">Edit</a>
                       <?php endif; ?>
                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row justify-content-center" >
            <div>
                <?php echo e($posts->links()); ?>

            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/posts/index.blade.php ENDPATH**/ ?>