<?php $__env->startSection('title',"| $post->title"); ?>


<?php $__env->startSection('content'); ?>
<br>
<div class="row">
    <div class="col-md-8">

        <h1><?php echo e($post->title); ?></h1>
        <small> Posted by:<?php echo e($post->user->name); ?></small>
         <p>Posted in: <?php echo e($post->category->name); ?></p>
         <?php if($post->post_image !=null): ?>
             <img src="<?php echo e(asset('images/'.$post->post_image)); ?>"height="300" width="300" />
        <?php endif; ?>
        <div class="tags">
             <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="label label-info"># <?php echo e($tag->name); ?></span>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p class="lead"><?php echo e($post->content); ?></p>
    <hr>
    <h5>Comments<small> <?php echo e($post->comments()->count()); ?> total </small></h5>
   <!-- <div style="margin-bottom:50px">
        <textarea class="form-control" row="3" name="comment_content" placeholder="Add a comment here" v-model="commentBlock"></textarea>
        <button class="btn btn-success" style="margin-top:10px">Add Comment</button>
    </div>-->
    <div class="comments">
        <ul class="list-group">
           <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <hr>
            <li class="list-group-item">
                <p>by <?php echo e($comment->user->name); ?> <?php echo e(date( 'M j, Y h:ia',strtotime($comment->created_at))); ?> &nbsp;</strong></p>
                <?php echo e($comment-> comment_content); ?>

        <div class="row">
            <div class="col-sm-10 ">
                <form method="GET" action="<?php echo e(route('comments.edit' ,$comment->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$comment)): ?>
                             <input type="submit" value="Edit" class="btn btn-primary float-right mt-2">
                    <?php endif; ?>
                </form>
            </div>
            <form method="POST" action="<?php echo e(route('comments.destroy',['id' =>$comment->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$comment)): ?>
                        <input type="submit" value="Delete" class="btn btn-danger float-right mt-2 "> 
                    <?php endif; ?>
            </form>
            </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <!--<div class="media" v-for="comment in comments">
        <div class="media-body">
           <h5 class="media-heading">by {{comment.user.name}}</h5>
           <p>{{comment.comment_content}}</p>
           <span>on {{comment.created_at}}</span>
        </div>
    </div>-->
    <br/>
    <div class="row">
            <div class="col-md-8">
                 <form method="POST" action="<?php echo e(route('comments.store',$post->id)); ?>">
                <?php echo csrf_field(); ?>
               <div class="form-group">
                <textarea id="comment_content " rows="5"  placeholder="Your comment here" name="comment_content"  class="form-control" value="<?php echo e(old('comment_content')); ?>"></textarea>
                </div>
                 <div class="form-group">
                    <button type="submit" class="btn btn-primary">Add Comment</button>
                 </div>

               <!-- <div class="form-group">
                     <label name="name" >Name: </label>
                     <input id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                 </div>-->
                
              <!-- <div style="margin-bottom:50px;" v-if="user">
                <textarea id="comment_content" rows="3" placeholder="Your comment here" name="comment_content"  class="form-control" v-model="commentBlock"></textarea>
                <button class= "btn btn-primary" style="margin-top:10px" @click.prevent="postComment">Add Comment</button>
                </div>-->
                <!--<div v-else>
                    <h5>Login to add your comment</h5><button class="btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
                </div>-->
    
            </form>
            </div>
        </div>
        </div>
</div>
<div class="col-md-4">
    <div class="well">
    <dl class="dl-horizontal">
            <dt>View: <?php echo e($post->page_view); ?>  </dt>
        </dl>
        <dl class="dl-horizontal">
            <dt>Create at: <?php echo e(date('M j, Y h:ia',strtotime($post->created_at))); ?> </dt>
        </dl>
        <dl class="dl-horizontal">
            <dt>Category: <?php echo e($post->category->name); ?> </dt>
        </dl>
        <dl class="dl-horizontal">
            <dt>Last updated at: <?php echo e(date('M j, Y h:ia', strtotime($post->updated_at))); ?></dt>
        </dl>
        <hr>
        <div class="row">
            <div class="col-sm-6">
                <form method="GET" action="<?php echo e(route('posts.edit' ,$post->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>
                        <input type="submit" value="Edit" class="btn btn-primary btn-block">
                    <?php endif; ?>
                </form>  
            </div>
            <div class="col-sm-6">
            <form method="POST" action="<?php echo e(route('posts.destroy',['id' =>$post->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$post)): ?>
                          <input type="submit" value="Delete" class="btn btn-danger btn-block">
                    <?php endif; ?>
            </form>
            </div>
            <div class="row">
                <div class="col-md-12 ">
                    <br>
                    <a  href="<?php echo e(route('posts.index')); ?>" class=" btn btn-primary  btn-d-block">Show all blog posts</a>
                </div>
            </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<!--<?php $__env->startSection('scripts'); ?>
<script>
   const app=new Vue({
       el:'#app',
       data: {
           comments: {},
           commentBlock:'',
           post:<?php echo $post->toJson(); ?>,
           user:<?php echo Auth::check() ? Auth::user()->toJson():'null'; ?>

       },
       mounted(){
           this.getComments();
       }, 
       methods:{
           getComments(){
               axios.get('api/posts/'+this.post.id+'/comments')
                    .then((response)=>{
                        this.comments=response.data
                    })
                    .catch(function(error)){
                        console.log(error);
                    }
                });
           },
           postComment(){
               axios.post('api/posts/'+this.post.id+'/comment',{
                   api_token: this.user.api_token,
                   comment_content:this:commentBlock
               })
               .then((response)=>{
                   this.comments.unshift(response.data);
                   this.commentBlock='';

               })
               .catch(function(error){
                   console.log(error);
               });
           }
       }
   });
</script>
<?php $__env->stopSection(); ?>-->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/posts/show.blade.php ENDPATH**/ ?>