<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/vagrant/laravel/BlogApplication/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>