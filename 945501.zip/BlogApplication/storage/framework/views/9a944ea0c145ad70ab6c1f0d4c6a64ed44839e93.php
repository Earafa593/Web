<?php $__env->startSection('title','About me'); ?>
<?php $__env->startSection('content'); ?>

            <div class="content">
                <div class="title m-b-md">
                    <h1> About <?php echo e($fullName); ?> </h1>

                    <p>This is a simple blog application created using Laravel !!</p>
                    <P>You can contacnt me by email <?php echo e($email); ?></p>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/about.blade.php ENDPATH**/ ?>