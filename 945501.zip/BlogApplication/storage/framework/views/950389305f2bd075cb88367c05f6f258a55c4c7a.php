<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
           <img src="<?php echo e(asset('images/'.$user->profile_pic)); ?>" style="width:150px; height:150px; float:left; border-radius:50%; margin-right:25px;">
           <h2><?php echo e($user->name); ?>'s Profile</h2>
            <form enctype="multipart/form-data" action="<?php echo e(route('profiles.update')); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('PUT'); ?>
                <label>Update Profile Image</label>
                <input type="file" name="profile_pic">
                <input type="submit" value="Save Profile Picture" class="pull-right btn btn-sm btn-primary"></input>
            </form>
        </div>
    </div>
<div class="row">
    <div class="col-md-12">
    <h2><?php echo e($user->name); ?>'s Posts</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
           <!-- <a href="<?php echo e(route('posts.create')); ?>" class=" btn btn-default btn-outline-primary " style="float:right">Create New Post</a>-->
                <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($post->id); ?></th>
                    <td><?php echo e($post->title); ?></td>
                    <td><a href="<?php echo e(route('posts.show',$post->id)); ?>" class="btn btn-default btn-outline-primary  mr-1">View </a><a href="<?php echo e(route('posts.edit',$post->id)); ?>" class="btn btn-default btn-outline-primary">Edit</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php if(Auth::check()!=null): ?>
        <?php if($user->isAdmin == $user->id): ?>
        <nav>
        <a class= " btn btn-default btn btn-dark "  href="<?php echo e(route('categories.index')); ?>">View Categories</a>
        <a class= " btn btn-default btn btn-dark"   href="<?php echo e(route('tags.index')); ?>">View Tags</a>
         <?php endif; ?>
         <?php endif; ?>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/profiles/show.blade.php ENDPATH**/ ?>