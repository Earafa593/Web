<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add Profile</div>
                <div class="card-body">
                <form method="POST" action="<?php echo e(route('profiles.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label name="name" >Name: </label>
                        <input id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                    </div>
                    <br>
                    <label name="profile_pic">Profile Picture: </label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic" value="<?php echo e(old('profile_pic')); ?>">
                        <label class="custom-file-label" for="profile_pic">Choose file</label>
                    </div>
                    </div>
                    <input  type="submit" value="Create Profile" ></input>
                    <!--<div class="form-group">
                        <label name="profile_pic">Profile Picture: </label>
                        <input id="profile_pic" type= "file "name="profile_pic" rows="10" class="fform-control-file" value="<?php echo e(old('profile_pic')); ?>"></textarea>
                    </div>-->
        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/profiles/profile.blade.php ENDPATH**/ ?>