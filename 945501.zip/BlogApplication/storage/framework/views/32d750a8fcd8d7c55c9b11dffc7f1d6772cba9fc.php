<?php $__env->startSection('title', '| Create new post'); ?>
<?php $__env->startSection('stylesheets'); ?>
    { !! HTML::style('css/select2.min.css') !!}

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <h1>Create New Post</h1>
        <form method="POST" action="<?php echo e(route('posts.store')); ?>"  enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label name="title" >Title: </label>
                <input id="title" name="title" class="form-control" value="<?php echo e(old('title')); ?>">
            </div>
            <label name="category">Category</label>
            <select class="form-control" name="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"
                        <?php if($category->id == old('category_id')): ?>
                            selcted="selected"
                        <?php endif; ?>
                        > <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <label name="tags">Tags --You can select multiple tags</label>
            <select class="form-control select2-multi" name="tags[]" multiple="multiple">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tag->id); ?>"
                        <?php if($tag->id == old('tag_id')): ?>
                            selcted="selected"
                        <?php endif; ?>
                        > <?php echo e($tag->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <hr>
            <label>Upload Post Image</label>
             <input type="file" name="post_image">
            <div class="form-group">
                <label name="content">Post content: </label>
                <textarea id="content" name="content" rows="10" class="form-control" value="<?php echo e(old('content')); ?>"></textarea>
            </div>
            <hr>
            <input type="submit" value="Create Post"> 
            <a href ="<?php echo e(route('posts.index')); ?>">Cancel</a>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        { !! HTML::script('js/select2.min.js') !!}
        $('.select2-multi').select2();
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/posts/create.blade.php ENDPATH**/ ?>