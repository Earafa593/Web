<?php $__env->startSection('title','Edit Blog Post'); ?>

<?php $__env->startSection('stylesheets'); ?>
    { !! HTML::style('css/select2.min.css') !!}

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
    <h1>Edit Post</h1>
</div>
<div class="pull-right">
    <a class="btn btn-primary" href="<?php echo e(route('posts.index')); ?>">Back to blog posts</a>
</div>
</div>
        <div class="row">
            <div class="col-sm-6">
                <form  action="<?php echo e(route('posts.update',$post->id)); ?>" method="POST" enctype="multipart/form-data" >
                    <!--<input type="hidden" name="_method" value="PUT">-->
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class= "form-group">
                        <label for="title">Title: </label>
                        <input type="text" class="form-control" name="title" value="<?php echo e($post->title); ?>"/>
                    </div>
                    <label for="category">Category</label>
                    <br/>
                    <select  name="category_id"> 
                         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($key); ?>" <?php echo e(($key =$post->category_id) ? "selected" : ""); ?>><?php echo e($value); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </select>
                    <div class="form-group">
                        <label for="content">Body</label>
                        <textarea id="content" class="form-control" rows="5" name="content" ><?php echo e($post->content); ?></textarea>
                    </div>
                    <label>Upload Post Image</label>
                    <input type="file" name="post_image">
                    <br/>
                    <hr>
                    <div class="form-group">
                   <button type="submit" class="btn btn-primary">Save changes</button>
            
            </div>
                 </form>
            </div>
            
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/posts/edit.blade.php ENDPATH**/ ?>