<?php $__env->startSection('title','All Categories'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-md-8">
        <h1>Tags:</h1>
   </div>
   <hr>
</div>
<div class="row">
    <div class="col-md-8">
        <table class="table table-striped">
            <thead class="table-dark" >
                <th>#</th>
                <th>Name</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($tag->id); ?></th>
                        <td><a href="<?php echo e(route('tags.show',$tag->id)); ?>"><?php echo e($tag->name); ?></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row justify-content-center">
            <div>
                <?php echo e($tags ->links()); ?>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="well">
        <h2> Add New Tag</h2>
        <form method="POST" action="<?php echo e(route('tags.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label name="name" >Name: </label>
                <input id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
            </div>
            <input type="submit" value="Create New Tag"> 
        </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/BlogApplication/resources/views/tags/index.blade.php ENDPATH**/ ?>